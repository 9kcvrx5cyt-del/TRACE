from models.segmentor import build_sctr

__all__ = ["build_sctr"]
