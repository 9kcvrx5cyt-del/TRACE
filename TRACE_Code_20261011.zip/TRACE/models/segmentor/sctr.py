from pathlib import Path

import torch
import torch.nn.functional as F
from torch import nn

from models.decoder import StructureConsistentTailDecoder
from models.encoder import VSSEncoder


class SCTR(nn.Module):
    def __init__(self, backbone, embed_dims, args=None):
        super().__init__()
        self.args = args
        self.backbone = backbone
        decoder_dim = getattr(args, "decoder_dim", 24)
        decoder_dropout = getattr(args, "decoder_dropout", 0.1)
        aux_loss_weight = getattr(args, "aux_loss_weight", 0.0)
        boundary_loss_weight = getattr(args, "boundary_loss_weight", 0.0)
        use_boundary_supervision = bool(getattr(args, "enable_boundary_supervision", False))
        enable_strip_pooling = not getattr(args, "disable_strip_pooling", False)
        strip_pool_order = getattr(args, "strip_pool_order", "after_recovery")
        strip_pool_sizes = (
            getattr(args, "strip_pool_size_1", 20),
            getattr(args, "strip_pool_size_2", 12),
        )
        self.tail = StructureConsistentTailDecoder(
            embed_dims,
            decoder_dim=decoder_dim,
            dropout=decoder_dropout,
            size=(args.load_width, args.load_height),
            enable_aux_heads=aux_loss_weight > 0,
            enable_boundary_head=use_boundary_supervision and boundary_loss_weight > 0,
            enable_strip_pooling=enable_strip_pooling,
            strip_pool_order=strip_pool_order,
            strip_pool_sizes=strip_pool_sizes,
        )

    def forward(self, samples):
        encoder_features = self.backbone(samples)
        return self.tail(encoder_features)


class DiceLoss(nn.Module):
    def __init__(self, smooth=1.0, dims=(-2, -1)):
        super().__init__()
        self.smooth = smooth
        self.dims = dims

    def forward(self, logits, targets):
        true_positive = (logits * targets).sum(self.dims)
        false_positive = (logits * (1 - targets)).sum(self.dims)
        false_negative = ((1 - logits) * targets).sum(self.dims)
        dice = (2 * true_positive + self.smooth) / (
            2 * true_positive + false_positive + false_negative + self.smooth
        )
        return 1 - dice.mean()


class SCTRTrainingLoss(nn.Module):
    def __init__(self, args):
        super().__init__()
        self.args = args
        self.bce_loss = nn.BCEWithLogitsLoss()
        self.dice_loss = DiceLoss()
        self.aux_stage_weights = [1.0, 0.8, 0.6, 0.4]
        self.last_components = {}

    def _segmentation_loss(self, logits, targets):
        bce = self.bce_loss(logits, targets)
        dice = self.dice_loss(logits.sigmoid(), targets)
        total = self.args.BCELoss_ratio * bce + self.args.DiceLoss_ratio * dice
        return total, bce, dice

    def _make_boundary_target(self, targets):
        kernel_size = int(getattr(self.args, "boundary_kernel_size", 3))
        kernel_size = max(3, kernel_size)
        if kernel_size % 2 == 0:
            kernel_size += 1
        padding = kernel_size // 2
        targets = targets.float()
        dilated = F.max_pool2d(targets, kernel_size=kernel_size, stride=1, padding=padding)
        eroded = -F.max_pool2d(-targets, kernel_size=kernel_size, stride=1, padding=padding)
        return (dilated - eroded).clamp_(0.0, 1.0)

    def _boundary_loss(self, logits, targets):
        boundary_target = self._make_boundary_target(targets)
        positives = boundary_target.sum()
        negatives = boundary_target.new_tensor(float(boundary_target.numel())) - positives
        max_pos_weight = float(getattr(self.args, "boundary_pos_weight_cap", 10.0))
        pos_weight = (negatives / positives.clamp_min(1.0)).clamp(1.0, max_pos_weight).detach().reshape(1)
        bce = F.binary_cross_entropy_with_logits(logits, boundary_target, pos_weight=pos_weight)
        dice = self.dice_loss(logits.sigmoid(), boundary_target)
        total = 0.7 * bce + 0.3 * dice
        return total, bce, dice

    def _record_components(self, component_map):
        self.last_components = {
            key: float(value.detach().item()) if torch.is_tensor(value) else float(value)
            for key, value in component_map.items()
        }

    def forward(self, predictions, targets):
        if isinstance(predictions, dict):
            main_loss, main_bce, main_dice = self._segmentation_loss(predictions["main"], targets)
            total_loss = main_loss
            components = {
                "main": main_loss,
                "main_bce": main_bce,
                "main_dice": main_dice,
            }

            aux_predictions = predictions.get("aux", [])
            aux_loss_weight = float(getattr(self.args, "aux_loss_weight", 0.0))
            if aux_predictions and aux_loss_weight > 0:
                stage_weights = self.aux_stage_weights[: len(aux_predictions)]
                weighted_aux_loss = 0.0
                weight_sum = 0.0
                for stage_weight, aux_prediction in zip(stage_weights, aux_predictions):
                    aux_loss, _, _ = self._segmentation_loss(aux_prediction, targets)
                    weighted_aux_loss = weighted_aux_loss + stage_weight * aux_loss
                    weight_sum += stage_weight
                aux_loss = weighted_aux_loss / max(weight_sum, 1e-6)
                total_loss = total_loss + aux_loss_weight * aux_loss
                components["aux"] = aux_loss

            boundary_prediction = predictions.get("boundary")
            use_boundary_supervision = bool(getattr(self.args, "enable_boundary_supervision", False))
            boundary_loss_weight = (
                float(getattr(self.args, "boundary_loss_weight", 0.0)) if use_boundary_supervision else 0.0
            )
            if boundary_prediction is not None and boundary_loss_weight > 0:
                boundary_loss, boundary_bce, boundary_dice = self._boundary_loss(boundary_prediction, targets)
                total_loss = total_loss + boundary_loss_weight * boundary_loss
                components["boundary"] = boundary_loss
                components["boundary_bce"] = boundary_bce
                components["boundary_dice"] = boundary_dice

            components["total"] = total_loss
            self._record_components(components)
            return total_loss

        total_loss, bce, dice = self._segmentation_loss(predictions, targets)
        self._record_components(
            {
                "main": total_loss,
                "main_bce": bce,
                "main_dice": dice,
                "total": total_loss,
            }
        )
        return total_loss


def build_sctr(args):
    device = torch.device(args.device)
    args.device = torch.device(args.device)
    dataset_name = Path(args.dataset_path).name
    nbins = getattr(args, "nbins", 0)
    if not nbins or nbins <= 0:
        nbins = 36 if dataset_name == "Crack500" else 180
    args.nbins = nbins
    cell_size = getattr(args, "cell_size", 8)
    g_ratio = getattr(args, "g_ratio", 0.5)

    embed_dims = [16, 32, 64, 128]
    depths = [1, 1, 1, 1]
    state_dims = [8, 8, 16, 16]

    backbone = VSSEncoder(
        in_dim=3,
        embed_dim=embed_dims,
        depths=depths,
        mlp_ratio=2.0,
        state_dim=state_dims,
        nbins=nbins,
        cell_size=(cell_size, cell_size),
        g_ratio=g_ratio,
    )
    model = SCTR(backbone, embed_dims, args).to(device)

    criterion = SCTRTrainingLoss(args).to(device)
    return model, criterion
