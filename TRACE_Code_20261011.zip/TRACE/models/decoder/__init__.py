from .sctr_decoder import StructureConsistentTailDecoder

__all__ = ["StructureConsistentTailDecoder"]
