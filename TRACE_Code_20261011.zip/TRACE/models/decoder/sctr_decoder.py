import torch
import torch.nn as nn
import torch.nn.functional as F


def _choose_compatible_groups(channels, target_groups):
    groups = min(target_groups, channels)
    while channels % groups != 0 and groups > 1:
        groups -= 1
    return groups


def make_group_norm(channels):
    return nn.GroupNorm(_choose_compatible_groups(channels, max(1, channels // 8)), channels)


class ProjectionBlock(nn.Module):
    def __init__(self, in_channels, out_channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1, bias=False),
            make_group_norm(out_channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class DepthwiseRefineBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, groups=channels, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        return self.block(x)


class TopDownFusionBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.mix = nn.Sequential(
            nn.Conv2d(channels * 2, channels, kernel_size=1, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
        )
        self.refine = DepthwiseRefineBlock(channels)

    def forward(self, lateral, topdown=None):
        if topdown is not None:
            topdown = F.interpolate(topdown, size=lateral.shape[-2:], mode="bilinear", align_corners=False)
            lateral = self.mix(torch.cat([lateral, topdown], dim=1))
        return self.refine(lateral)


class ShallowSpatialGate(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.gate = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=1, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, 1, kernel_size=1),
            nn.Sigmoid(),
        )

    def forward(self, x):
        return 0.5 + self.gate(x)


class AuxiliaryPredictionHead(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, 1, kernel_size=1),
        )

    def forward(self, x):
        return self.block(x)


class StripPoolingBlock(nn.Module):
    def __init__(self, channels, pool_sizes=(20, 12)):
        super().__init__()
        pool_sizes = tuple(max(1, int(size)) for size in pool_sizes)
        inter_channels = max(1, channels // 4)
        self.pool1 = nn.AdaptiveAvgPool2d(pool_sizes[0])
        self.pool2 = nn.AdaptiveAvgPool2d(pool_sizes[1])

        self.conv1_1 = nn.Sequential(
            nn.Conv2d(channels, inter_channels, kernel_size=1, bias=False),
            make_group_norm(inter_channels),
            nn.ReLU(inplace=True),
        )
        self.conv1_2 = nn.Sequential(
            nn.Conv2d(channels, inter_channels, kernel_size=1, bias=False),
            make_group_norm(inter_channels),
            nn.ReLU(inplace=True),
        )
        self.conv2_0 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(inter_channels),
        )
        self.conv2_1 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(inter_channels),
        )
        self.conv2_2 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(inter_channels),
        )
        self.conv2_3 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=(1, 3), padding=(0, 1), bias=False),
            make_group_norm(inter_channels),
        )
        self.conv2_4 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=(3, 1), padding=(1, 0), bias=False),
            make_group_norm(inter_channels),
        )
        self.conv2_5 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(inter_channels),
            nn.ReLU(inplace=True),
        )
        self.conv2_6 = nn.Sequential(
            nn.Conv2d(inter_channels, inter_channels, kernel_size=3, padding=1, bias=False),
            make_group_norm(inter_channels),
            nn.ReLU(inplace=True),
        )
        self.conv3 = nn.Sequential(
            nn.Conv2d(inter_channels * 2, channels, kernel_size=1, bias=False),
            make_group_norm(channels),
        )

    def forward(self, x):
        _, _, height, width = x.size()
        branch_local = self.conv1_1(x)
        branch_strip = self.conv1_2(x)

        pooled_local = self.conv2_0(branch_local)
        pooled_scale_1 = F.interpolate(
            self.conv2_1(self.pool1(branch_local)),
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )
        pooled_scale_2 = F.interpolate(
            self.conv2_2(self.pool2(branch_local)),
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )
        strip_horizontal = F.interpolate(
            self.conv2_3(branch_strip.mean(dim=2, keepdim=True)),
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )
        strip_vertical = F.interpolate(
            self.conv2_4(branch_strip.mean(dim=3, keepdim=True)),
            size=(height, width),
            mode="bilinear",
            align_corners=False,
        )

        branch_local = self.conv2_5(F.relu_(pooled_local + pooled_scale_1 + pooled_scale_2))
        branch_strip = self.conv2_6(F.relu_(strip_horizontal + strip_vertical))
        fused = self.conv3(torch.cat([branch_local, branch_strip], dim=1))
        return F.relu_(x + fused)


class BottleneckDepthwiseConv(nn.Module):
    def __init__(self, in_channels, out_channels, mid_channels, kernel_size, stride=1, padding=0):
        super().__init__()
        self.pointwise_1 = nn.Conv2d(in_channels, mid_channels, kernel_size=1, bias=False)
        self.depthwise = nn.Conv2d(
            mid_channels,
            mid_channels,
            kernel_size=kernel_size,
            stride=stride,
            padding=padding,
            groups=mid_channels,
            bias=False,
        )
        self.pointwise_2 = nn.Conv2d(mid_channels, out_channels, kernel_size=1, bias=False)

    def forward(self, x):
        x = self.pointwise_1(x)
        x = self.depthwise(x)
        x = self.pointwise_2(x)
        return x


class DenseContextBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        mid_channels = max(1, channels // 8)
        norm_groups = _choose_compatible_groups(channels, max(1, channels // 16))
        self.block1 = nn.Sequential(
            BottleneckDepthwiseConv(channels, channels, mid_channels, kernel_size=3, padding=1),
            nn.GroupNorm(norm_groups, channels),
            nn.ReLU(inplace=True),
        )
        self.block2 = nn.Sequential(
            BottleneckDepthwiseConv(channels, channels, mid_channels, kernel_size=3, padding=1),
            nn.GroupNorm(norm_groups, channels),
            nn.ReLU(inplace=True),
        )
        self.block3 = nn.Sequential(
            BottleneckDepthwiseConv(channels, channels, mid_channels, kernel_size=1),
            nn.GroupNorm(norm_groups, channels),
            nn.ReLU(inplace=True),
        )
        self.block4 = nn.Sequential(
            BottleneckDepthwiseConv(channels, channels, mid_channels, kernel_size=1),
            nn.GroupNorm(norm_groups, channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, x):
        residual = x
        interaction = self.block2(self.block1(x))
        gate = self.block3(x)
        x = self.block4(interaction * gate)
        return x + residual


class DenseAggregationBlock(nn.Module):
    def __init__(self, channels):
        super().__init__()
        dense_channels = channels * 2
        self.pre_mix = nn.Sequential(
            nn.Conv2d(channels * 4, dense_channels, kernel_size=1, bias=False),
            make_group_norm(dense_channels),
            nn.ReLU(inplace=True),
        )
        self.context = DenseContextBlock(dense_channels)
        self.post_mix = nn.Sequential(
            nn.Conv2d(dense_channels, channels, kernel_size=1, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(channels, channels, kernel_size=3, padding=1, groups=channels, bias=False),
            make_group_norm(channels),
            nn.ReLU(inplace=True),
        )

    def forward(self, features):
        x = self.pre_mix(torch.cat(features, dim=1))
        x = self.context(x)
        return self.post_mix(x)


class StructureConsistentTailDecoder(nn.Module):
    def __init__(
        self,
        embed_dims,
        decoder_dim=24,
        dropout=0.1,
        size=(512, 512),
        enable_aux_heads=False,
        enable_boundary_head=False,
        enable_strip_pooling=True,
        strip_pool_order="after_recovery",
        strip_pool_sizes=(20, 12),
    ):
        super().__init__()
        self.output_size = size
        self.enable_aux_heads = enable_aux_heads
        self.enable_boundary_head = enable_boundary_head
        self.enable_strip_pooling = enable_strip_pooling
        self.strip_pool_order = strip_pool_order

        self.projections = nn.ModuleList([ProjectionBlock(in_channels, decoder_dim) for in_channels in embed_dims])
        self.fusion_blocks = nn.ModuleList([TopDownFusionBlock(decoder_dim) for _ in embed_dims])
        self.shallow_gate = ShallowSpatialGate(decoder_dim)
        self.dense_aggregation = DenseAggregationBlock(decoder_dim)
        self.p1_merge = nn.Sequential(
            nn.Conv2d(decoder_dim * 2, decoder_dim, kernel_size=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(decoder_dim, decoder_dim, kernel_size=3, padding=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
        )
        self.full_resolution_fusion = nn.Sequential(
            nn.Conv2d(decoder_dim * 4, decoder_dim, kernel_size=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(decoder_dim, decoder_dim, kernel_size=3, padding=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(decoder_dim, decoder_dim, kernel_size=3, padding=1, groups=decoder_dim, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
        )
        self.strip_pool = StripPoolingBlock(decoder_dim, pool_sizes=strip_pool_sizes) if enable_strip_pooling else nn.Identity()
        self.parallel_merge = nn.Sequential(
            nn.Conv2d(decoder_dim * 2, decoder_dim, kernel_size=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
            nn.Conv2d(decoder_dim, decoder_dim, kernel_size=3, padding=1, bias=False),
            make_group_norm(decoder_dim),
            nn.ReLU(inplace=True),
        )
        self.main_dropout = nn.Dropout(p=dropout)
        self.main_head = nn.Conv2d(decoder_dim, 1, kernel_size=1)
        self.auxiliary_heads = nn.ModuleList([AuxiliaryPredictionHead(decoder_dim) for _ in embed_dims])
        self.boundary_head = AuxiliaryPredictionHead(decoder_dim)
        self.tail_pyramid = []

    def _align_to_p1(self, feature, target_size):
        if feature.shape[-2:] == target_size:
            return feature
        return F.interpolate(feature, size=target_size, mode="bilinear", align_corners=False)

    def _apply_multiscale_strip_pool(self, features):
        if not self.enable_strip_pooling:
            return list(features)
        return [self.strip_pool(feature) for feature in features]

    def _run_recovery_branch(self, projected_features):
        x1, x2, x3, x4 = projected_features
        p4 = self.fusion_blocks[3](x4)
        p3 = self.fusion_blocks[2](x3, p4)
        p2 = self.fusion_blocks[1](x2, p3)
        p1 = self.fusion_blocks[0](x1, p2)

        target_size = p1.shape[-2:]
        p2_aligned = self._align_to_p1(p2, target_size)
        p3_aligned = self._align_to_p1(p3, target_size)
        p4_aligned = self._align_to_p1(p4, target_size)

        gate = self.shallow_gate(p1)
        gated_p2 = p2_aligned * gate
        gated_p3 = p3_aligned * gate
        gated_p4 = p4_aligned * gate

        dense_residual = self.dense_aggregation([p1, gated_p2, gated_p3, gated_p4])
        p1_enhanced = self.p1_merge(torch.cat([p1, dense_residual], dim=1))
        return p1_enhanced, p2, p3, p4, gated_p2, gated_p3, gated_p4

    def _fuse_full_resolution(self, p1_feature, p2_feature, p3_feature, p4_feature):
        p1_full = F.interpolate(p1_feature, size=self.output_size, mode="bilinear", align_corners=False)
        p2_full = F.interpolate(p2_feature, size=self.output_size, mode="bilinear", align_corners=False)
        p3_full = F.interpolate(p3_feature, size=self.output_size, mode="bilinear", align_corners=False)
        p4_full = F.interpolate(p4_feature, size=self.output_size, mode="bilinear", align_corners=False)
        return self.full_resolution_fusion(torch.cat([p1_full, p2_full, p3_full, p4_full], dim=1))

    def forward(self, encoder_features):
        projected_features = [
            projection(feature) for projection, feature in zip(self.projections, encoder_features)
        ]

        recovery_input = projected_features
        if self.enable_strip_pooling and self.strip_pool_order == "before_recovery":
            recovery_input = self._apply_multiscale_strip_pool(projected_features)

        p1_enhanced, p2, p3, p4, gated_p2, gated_p3, gated_p4 = self._run_recovery_branch(recovery_input)
        self.tail_pyramid = [p1_enhanced, p2, p3, p4]

        fused = self._fuse_full_resolution(p1_enhanced, gated_p2, gated_p3, gated_p4)
        if self.enable_strip_pooling:
            if self.strip_pool_order == "after_recovery":
                fused = self.strip_pool(fused)
            elif self.strip_pool_order == "parallel":
                sp_x1, sp_x2, sp_x3, sp_x4 = self._apply_multiscale_strip_pool(projected_features)
                parallel_fused = self._fuse_full_resolution(sp_x1, sp_x2, sp_x3, sp_x4)
                fused = self.parallel_merge(torch.cat([fused, parallel_fused], dim=1))
        main_logits = self.main_head(self.main_dropout(fused))

        if not self.training or (not self.enable_aux_heads and not self.enable_boundary_head):
            return main_logits

        outputs = {"main": main_logits}
        if self.enable_aux_heads:
            aux_features = [p1_enhanced, p2, p3, p4]
            outputs["aux"] = [
                F.interpolate(
                    head(feature),
                    size=self.output_size,
                    mode="bilinear",
                    align_corners=False,
                )
                for head, feature in zip(self.auxiliary_heads, aux_features)
            ]
        if self.enable_boundary_head:
            outputs["boundary"] = self.boundary_head(fused)
        return outputs
