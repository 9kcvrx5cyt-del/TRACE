# Release checks: 2026-10-11

- 48 Python source files parsed successfully with Python's AST parser.
- 64 archived Python/CUDA/C++/header files match the source archive by SHA-256.
- The manuscript's split manifest and topology evaluator are included separately.
- Isolated decoder smoke test passed on PyTorch 2.9.1+cpu, with a 64-by-64 output, four encoder-shaped random tensors, four auxiliary maps, and a boundary map. Forward output shapes, finite input gradients after backward, tensor-only evaluation output, and gate range (0.5, 1.5) were checked.
- A bounded scan found no GitHub-token patterns, AWS-access-key patterns, or private-key headers. This scan is not a guarantee against every possible secret format.
- Git metadata, Python caches, original datasets, model weights, experiment predictions, and machine-specific historical batch scripts are excluded.
- The root MIT license and existing per-file copyright headers are preserved. VMamba MIT and Mamba Apache-2.0 license texts are supplied under LICENSES.

Not validated in these packaging checks: full encoder imports and CUDA extension compilation; a fresh installation of the archived GPU environment; end-to-end 50-epoch training; checkpoint key conversion from earlier experimental trees; numerical reproduction of manuscript tables. The CPU decoder test is not an end-to-end reproducibility test.

The README records the archived checkpoint-selection protocol and per-dataset configurations without changing executable code. The historical implementation name SCTR is retained in Python APIs; the manuscript name is TRACE.
