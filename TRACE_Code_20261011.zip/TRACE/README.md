# TRACE

Tail Reconstruction with Axial Context and Edge Supervision for road crack segmentation.

This source release contains the retained MixerCSeg encoder and a prediction tail with high-resolution gated recovery, post-fusion axial context, and training-only region and boundary supervision.

The implementation was developed under the earlier name SCTR. Existing Python names (`SCTR`, `build_sctr`, `StructureConsistentTailDecoder`, and `tail.*` state-dict keys) are retained to avoid introducing another checkpoint-format change. TRACE is the manuscript name.

## Contents

- `main.py`: training entry point.
- `test.py`: prediction export from a checkpoint.
- `models/decoder/sctr_decoder.py`: gated cross-scale recovery and strip-pooling context.
- `models/segmentor/sctr.py`: full model construction and training losses.
- `datasets/`: image/mask loaders.
- `eval/evaluate.py`: region metrics.
- `reproducibility/TRACE_split_manifest.csv`: filename-level dataset split list.
- `reproducibility/topology_metrics.py`: centerline and related mask metrics.
- `VMamba/`: bundled encoder dependency and selective-scan CUDA sources.
- `LICENSES/` and `THIRD_PARTY_NOTICES.md`: third-party notices.

Raw datasets, trained weights, predictions, private run logs, and historical machine-specific batch scripts are not distributed.

## Environment

The archived installation recipe targets Linux, Python 3.10, PyTorch 2.1.0 with CUDA 11.8, and torchvision 0.16.0. It additionally uses the MMCV 1.x API, mmsegmentation 0.30.0, mmengine, timm, and a compiled selective-scan extension.

`requirements.txt` preserves the archived dependency list. `requirements-runtime-extra.txt` lists directly imported runtime packages absent from that list. These files are not a fully pinned, freshly tested environment lock. Match PyTorch, the CUDA toolkit, compiler, and MMCV 1.x before building the extension; installing MMCV 2.x is not compatible with the current imports.

The archived setup sequence is:

```bash
conda create -n trace python=3.10 -y
conda activate trace
pip install torch==2.1.0+cu118 torchvision==0.16.0+cu118 torchaudio==2.1.0+cu118 -f https://download.pytorch.org/whl/torch_stable.html
# Install an MMCV 1.x build compatible with the selected PyTorch/CUDA environment.
pip install -r requirements.txt
pip install -r requirements-runtime-extra.txt
cd VMamba/models/kernels/selective_scan
python setup.py install
cd ../../../..
```

The extension requires a CUDA development toolkit with NVCC; a PyTorch CUDA wheel alone does not supply that toolkit. Full environment installation, CUDA compilation, and end-to-end training have not been revalidated for this release.

## Data

Obtain the datasets from their original providers or the data links supplied by [MixerCSeg](https://github.com/spiderforest/MixerCSeg). Follow their individual access and usage conditions. Use the supplied split manifest to check filenames.

Each dataset root should retain its exact dataset name:

```text
/path/to/DeepCrack/
  train_img/
  train_lab/
  val_img/
  val_lab/
  test_img/
  test_lab/
```

The loader selects folders using the phase argument. Validation folders are not used by the archived default training command. CamCrack789 labels follow `target-<index>.png`; other labels use the image stem with a `.png` extension. The archived preprocessing resizes images and masks to 512 by 512, then binarizes masks.

## Manuscript configurations

Use the following values for both model construction and inference:

| Dataset | Decoder dropout | Strip pool sizes | Direction bins |
|---|---:|---|---:|
| DeepCrack | 0.10 | 20, 12 | 180 |
| CamCrack789 | 0.15 | 20, 12 | 180 |
| CrackMap | 0.05 | 24, 12 | 180 |
| Crack500 | 0.15 | 20, 12 | 36 |

Shared settings: seed 42; 50 epochs; batch size 1; AdamW learning rate 0.0005; weight decay 0.01; PolyLR minimum learning rate 0.000001; decoder width 24; auxiliary weight 0.3; boundary weight 0.2; boundary kernel 3; boundary positive-weight cap 10; BCE/Dice weights 0.87/0.13; `strip_pool_order=after_recovery`.

### Train

DeepCrack example:

```bash
python main.py \
  --dataset_path /path/to/DeepCrack \
  --output_dir ./checkpoints/weights --run_name trace_deepcrack \
  --epochs 50 --seed 42 --lr 5e-4 --weight_decay 0.01 \
  --batch_size_train 1 --batch_size_test 1 \
  --decoder_dim 24 --decoder_dropout 0.10 --nbins 180 \
  --strip_pool_order after_recovery --strip_pool_size_1 20 --strip_pool_size_2 12 \
  --aux_loss_weight 0.3 --enable_boundary_supervision --boundary_loss_weight 0.2 \
  --boundary_kernel_size 3 --boundary_pos_weight_cap 10 --eval_phase test
```

Change the dataset path, run name, dropout, strip sizes, and direction bins according to the table for the other datasets. No private server paths are required.

Protocol note: the archived implementation evaluates the test-labelled split after each epoch and retains the checkpoint with the highest mIoU. Dataset-specific settings were selected through parameter sweeps. This is the manuscript's recorded protocol; it is not an untouched held-out assessment. No training or selection behavior has been changed in this source release.

### Predict

Construct the same model configuration used for training:

```bash
python test.py \
  --dataset_path /path/to/DeepCrack \
  --checkpoint /path/to/checkpoint_best.pth \
  --save_root ./results/trace_deepcrack \
  --decoder_dim 24 --decoder_dropout 0.10 --nbins 180 \
  --strip_pool_order after_recovery --strip_pool_size_1 20 --strip_pool_size_2 12 \
  --aux_loss_weight 0.3 --enable_boundary_supervision --boundary_loss_weight 0.2
```

In particular, CrackMap uses strip sizes 24 and 12. `test.py` does not restore model arguments from the checkpoint automatically. It currently uses `strict=False` and prints missing/unexpected keys: inspect those lists before using any predictions. Compatibility of older experimental checkpoints with this cleaned code has not been established. No checkpoint is included.

### Evaluate

```bash
python eval/evaluate.py --result_path ./results/trace_deepcrack
python reproducibility/topology_metrics.py --pred-dir ./results/trace_deepcrack --help
```

The topology script exposes threshold modes; use the manuscript's specified mode for comparisons, rather than changing thresholds independently between methods.

## Verification scope

This is an implementation source release. Its model equations, command-line options, and dataset-specific settings were checked against the manuscript. Static syntax checks and an isolated CPU decoder smoke test are documented in the release checklist. Full encoder/CUDA execution, end-to-end training, original-checkpoint compatibility, and reproduction of the numerical tables are not claimed by these packaging checks.

## Attribution

The retained encoder and training infrastructure build on [MixerCSeg](https://github.com/spiderforest/MixerCSeg). VMamba and Mamba-derived code retain their existing copyright headers. The original root license is preserved; see [third-party notices](THIRD_PARTY_NOTICES.md) for the bundled dependency licenses.

The manuscript is in preparation for submission. This repository does not claim journal acceptance or publication.
