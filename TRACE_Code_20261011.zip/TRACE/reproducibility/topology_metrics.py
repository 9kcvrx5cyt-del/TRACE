#!/usr/bin/env python3
import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np


def parse_args():
    parser = argparse.ArgumentParser(
        description=(
            "Evaluate topology-sensitive crack-segmentation metrics from a "
            "directory containing *_pre.png and *_lab.png pairs."
        )
    )
    parser.add_argument("--pred-dir", required=True, help="Directory with *_pre.png / *_lab.png pairs.")
    parser.add_argument(
        "--threshold-mode",
        choices=["best_f1", "fixed"],
        default="best_f1",
        help="How to choose the binarization threshold for topology metrics.",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=None,
        help="Fixed threshold in [0, 1]. Required when --threshold-mode fixed.",
    )
    parser.add_argument(
        "--threshold-step",
        type=float,
        default=0.01,
        help="Threshold step used for the F1 / mIoU sweep.",
    )
    parser.add_argument(
        "--endpoint-radius",
        type=int,
        default=2,
        help="Radius r used by EPR@r and component preservation.",
    )
    parser.add_argument(
        "--component-metric-name",
        choices=["CPR", "CSR"],
        default="CPR",
        help="Output label for the component-level connectivity metric.",
    )
    parser.add_argument("--run-label", default="", help="Optional label stored in the summary.")
    parser.add_argument("--summary-json", default="", help="Optional summary JSON output path.")
    parser.add_argument("--per-image-csv", default="", help="Optional per-image CSV output path.")
    parser.add_argument("--summary-csv", default="", help="Optional CSV file to append the summary row to.")
    return parser.parse_args()


def load_image_pairs(pred_dir):
    pred_dir = Path(pred_dir)
    pred_paths = sorted(pred_dir.glob("*_pre.png"))
    if not pred_paths:
        raise FileNotFoundError(f"No *_pre.png files found in {pred_dir}")

    pairs = []
    for pred_path in pred_paths:
        stem = pred_path.name[:-8]
        gt_path = pred_dir / f"{stem}_lab.png"
        if not gt_path.is_file():
            raise FileNotFoundError(f"Missing GT pair for {pred_path.name}: {gt_path}")
        pred = cv2.imread(str(pred_path), cv2.IMREAD_GRAYSCALE)
        gt = cv2.imread(str(gt_path), cv2.IMREAD_GRAYSCALE)
        if pred is None or gt is None:
            raise RuntimeError(f"Failed to read pair: {pred_path} / {gt_path}")
        pairs.append(
            {
                "image_id": stem,
                "pred_path": pred_path,
                "gt_path": gt_path,
                "pred_prob": pred,
                "gt_mask": (gt > 127).astype(np.uint8),
            }
        )
    return pairs


def threshold_grid(step):
    count = int(round(1.0 / step))
    return [i * step for i in range(count)]


def binarize_prob(prob_mask, threshold):
    return ((prob_mask.astype(np.float32) / 255.0) > threshold).astype(np.uint8)


def pixel_counts(pred_bin, gt_bin):
    tp = int(np.sum((pred_bin == 1) & (gt_bin == 1)))
    fp = int(np.sum((pred_bin == 1) & (gt_bin == 0)))
    fn = int(np.sum((pred_bin == 0) & (gt_bin == 1)))
    tn = int(np.sum((pred_bin == 0) & (gt_bin == 0)))
    return tp, fp, fn, tn


def precision_recall_f1_from_counts(tp, fp, fn):
    precision = 1.0 if tp == 0 and fp == 0 else tp / (tp + fp)
    recall = 0.0 if tp + fn == 0 else tp / (tp + fn)
    f1 = 0.0 if precision + recall == 0 else 2.0 * precision * recall / (precision + recall)
    return precision, recall, f1


def sweep_best_f1(pairs, step):
    best = None
    for threshold in threshold_grid(step):
        tp = fp = fn = 0
        for pair in pairs:
            pred_bin = binarize_prob(pair["pred_prob"], threshold)
            cur_tp, cur_fp, cur_fn, _ = pixel_counts(pred_bin, pair["gt_mask"])
            tp += cur_tp
            fp += cur_fp
            fn += cur_fn
        precision, recall, f1 = precision_recall_f1_from_counts(tp, fp, fn)
        row = {
            "threshold": float(threshold),
            "precision": float(precision),
            "recall": float(recall),
            "f1": float(f1),
        }
        if best is None or row["f1"] > best["f1"]:
            best = row
    return best


def sweep_best_miou(pairs, step):
    best = None
    for threshold in threshold_grid(step):
        per_image = []
        for pair in pairs:
            pred_bin = binarize_prob(pair["pred_prob"], threshold)
            tp, fp, fn, tn = pixel_counts(pred_bin, pair["gt_mask"])
            iou_fg = 0.0 if tp + fp + fn == 0 else tp / (tp + fp + fn)
            iou_bg = 0.0 if tn + fp + fn == 0 else tn / (tn + fp + fn)
            per_image.append((iou_fg + iou_bg) / 2.0)
        mean_iou = float(np.mean(per_image))
        row = {"threshold": float(threshold), "mIoU": mean_iou}
        if best is None or row["mIoU"] > best["mIoU"]:
            best = row
    return best


def disk_kernel(radius):
    radius = max(int(radius), 0)
    size = 2 * radius + 1
    yy, xx = np.ogrid[-radius : radius + 1, -radius : radius + 1]
    return ((xx * xx + yy * yy) <= radius * radius).astype(np.uint8)


def skeletonize_binary(mask):
    img = ((mask > 0).astype(np.uint8) * 255)
    if img.max() == 0:
        return np.zeros_like(img, dtype=np.uint8)

    element = cv2.getStructuringElement(cv2.MORPH_CROSS, (3, 3))
    skeleton = np.zeros_like(img, dtype=np.uint8)
    while True:
        opened = cv2.morphologyEx(img, cv2.MORPH_OPEN, element)
        residue = cv2.subtract(img, opened)
        eroded = cv2.erode(img, element)
        skeleton = cv2.bitwise_or(skeleton, residue)
        img = eroded
        if cv2.countNonZero(img) == 0:
            break
    return (skeleton > 0).astype(np.uint8)


def skeleton_endpoints(skeleton):
    if skeleton.max() == 0:
        return np.zeros_like(skeleton, dtype=np.uint8)
    kernel = np.ones((3, 3), dtype=np.uint8)
    neighbor_count = cv2.filter2D(skeleton.astype(np.uint8), -1, kernel, borderType=cv2.BORDER_CONSTANT)
    neighbor_count = neighbor_count - skeleton
    return ((skeleton == 1) & (neighbor_count == 1)).astype(np.uint8)


def endpoint_recall(gt_endpoints, pred_endpoints, radius):
    gt_count = int(gt_endpoints.sum())
    if gt_count == 0:
        return 1.0, 0, 0
    kernel = disk_kernel(radius)
    pred_endpoint_buffer = cv2.dilate(pred_endpoints.astype(np.uint8), kernel, iterations=1)
    matched = int(np.sum((gt_endpoints == 1) & (pred_endpoint_buffer == 1)))
    return matched / gt_count, matched, gt_count


def component_preservation(gt_skeleton, pred_skeleton, radius):
    gt_labels_count, gt_labels = cv2.connectedComponents(gt_skeleton.astype(np.uint8), connectivity=8)
    pred_labels_count, pred_labels = cv2.connectedComponents(pred_skeleton.astype(np.uint8), connectivity=8)
    gt_endpoints = skeleton_endpoints(gt_skeleton)
    kernel = disk_kernel(radius)

    evaluable = 0
    preserved = 0

    for comp_label in range(1, gt_labels_count):
        gt_component = (gt_labels == comp_label).astype(np.uint8)
        if gt_component.sum() == 0:
            continue
        evaluable += 1
        gt_component_endpoints = ((gt_endpoints == 1) & (gt_component == 1)).astype(np.uint8)
        endpoint_count = int(gt_component_endpoints.sum())
        gt_buffer = cv2.dilate(gt_component, kernel, iterations=1)
        candidate_labels = np.unique(pred_labels[gt_buffer == 1])
        candidate_labels = [int(label) for label in candidate_labels if label > 0]

        is_preserved = False
        for pred_label in candidate_labels:
            pred_component = (pred_labels == pred_label).astype(np.uint8)
            pred_buffer = cv2.dilate(pred_component, kernel, iterations=1)
            if endpoint_count >= 2:
                covered = int(np.sum((gt_component_endpoints == 1) & (pred_buffer == 1)))
                if covered == endpoint_count:
                    is_preserved = True
                    break
            elif endpoint_count == 1:
                if np.any((gt_component_endpoints == 1) & (pred_buffer == 1)):
                    is_preserved = True
                    break
            else:
                overlap = int(np.sum((gt_component == 1) & (pred_buffer == 1)))
                if overlap / max(int(gt_component.sum()), 1) >= 0.8:
                    is_preserved = True
                    break
        if is_preserved:
            preserved += 1

    score = 1.0 if evaluable == 0 else preserved / evaluable
    return score, preserved, evaluable


def cldice_score(pred_bin, gt_bin):
    pred_skeleton = skeletonize_binary(pred_bin)
    gt_skeleton = skeletonize_binary(gt_bin)
    pred_skel_sum = int(pred_skeleton.sum())
    gt_skel_sum = int(gt_skeleton.sum())
    if pred_skel_sum == 0 and gt_skel_sum == 0:
        return 1.0, pred_skeleton, gt_skeleton
    tprec = 0.0 if pred_skel_sum == 0 else float(np.sum((pred_skeleton == 1) & (gt_bin == 1))) / pred_skel_sum
    tsens = 0.0 if gt_skel_sum == 0 else float(np.sum((gt_skeleton == 1) & (pred_bin == 1))) / gt_skel_sum
    score = 0.0 if tprec + tsens == 0 else 2.0 * tprec * tsens / (tprec + tsens)
    return score, pred_skeleton, gt_skeleton


def analyze_pairs(pairs, threshold, radius):
    rows = []
    total_endpoint_matches = 0
    total_gt_endpoints = 0
    total_preserved_components = 0
    total_evaluable_components = 0

    for pair in pairs:
        pred_bin = binarize_prob(pair["pred_prob"], threshold)
        gt_bin = pair["gt_mask"]
        tp, fp, fn, tn = pixel_counts(pred_bin, gt_bin)
        iou_fg = 0.0 if tp + fp + fn == 0 else tp / (tp + fp + fn)
        iou_bg = 0.0 if tn + fp + fn == 0 else tn / (tn + fp + fn)
        cldice, pred_skeleton, gt_skeleton = cldice_score(pred_bin, gt_bin)
        gt_endpoints = skeleton_endpoints(gt_skeleton)
        pred_endpoints = skeleton_endpoints(pred_skeleton)
        epr, endpoint_matches, gt_endpoint_count = endpoint_recall(gt_endpoints, pred_endpoints, radius)
        cpr, preserved_components, evaluable_components = component_preservation(
            gt_skeleton, pred_skeleton, radius
        )

        total_endpoint_matches += endpoint_matches
        total_gt_endpoints += gt_endpoint_count
        total_preserved_components += preserved_components
        total_evaluable_components += evaluable_components

        rows.append(
            {
                "image_id": pair["image_id"],
                "threshold": float(threshold),
                "fg_iou": float(iou_fg),
                "bg_iou": float(iou_bg),
                "miou_pair": float((iou_fg + iou_bg) / 2.0),
                "cldice": float(cldice),
                "epr": float(epr),
                "matched_gt_endpoints": int(endpoint_matches),
                "gt_endpoints": int(gt_endpoint_count),
                "cpr": float(cpr),
                "preserved_components": int(preserved_components),
                "evaluable_components": int(evaluable_components),
                "gt_positive_px": int(gt_bin.sum()),
                "pred_positive_px": int(pred_bin.sum()),
                "pred_path": str(pair["pred_path"]),
                "gt_path": str(pair["gt_path"]),
            }
        )

    cldice_mean = float(np.mean([row["cldice"] for row in rows]))
    epr_dataset = 1.0 if total_gt_endpoints == 0 else total_endpoint_matches / total_gt_endpoints
    cpr_dataset = 1.0 if total_evaluable_components == 0 else total_preserved_components / total_evaluable_components
    return rows, cldice_mean, epr_dataset, cpr_dataset, total_endpoint_matches, total_gt_endpoints, total_preserved_components, total_evaluable_components


def ensure_parent(path_str):
    if not path_str:
        return
    Path(path_str).parent.mkdir(parents=True, exist_ok=True)


def write_per_image_csv(path_str, rows):
    ensure_parent(path_str)
    fieldnames = [
        "image_id",
        "threshold",
        "fg_iou",
        "bg_iou",
        "miou_pair",
        "cldice",
        "epr",
        "matched_gt_endpoints",
        "gt_endpoints",
        "cpr",
        "preserved_components",
        "evaluable_components",
        "gt_positive_px",
        "pred_positive_px",
        "pred_path",
        "gt_path",
    ]
    with open(path_str, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for row in rows:
            writer.writerow(row)


def append_summary_csv(path_str, summary, component_metric_name):
    ensure_parent(path_str)
    fieldnames = [
        "run_label",
        "pred_dir",
        "threshold_mode",
        "anchor_threshold",
        "best_f1_threshold",
        "best_f1",
        "best_precision",
        "best_recall",
        "best_miou_threshold",
        "best_miou",
        "cldice",
        "epr_at_r",
        component_metric_name,
        "endpoint_radius",
        "matched_gt_endpoints",
        "gt_endpoints",
        "preserved_components",
        "evaluable_components",
        "per_image_csv",
        "summary_json",
    ]
    write_header = not Path(path_str).is_file()
    with open(path_str, "a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        if write_header:
            writer.writeheader()
        writer.writerow(
            {
                "run_label": summary["run_label"],
                "pred_dir": summary["pred_dir"],
                "threshold_mode": summary["threshold_mode"],
                "anchor_threshold": summary["anchor_threshold"],
                "best_f1_threshold": summary["best_f1_threshold"],
                "best_f1": summary["best_f1"],
                "best_precision": summary["best_precision"],
                "best_recall": summary["best_recall"],
                "best_miou_threshold": summary["best_miou_threshold"],
                "best_miou": summary["best_miou"],
                "cldice": summary["cldice"],
                "epr_at_r": summary["epr_at_r"],
                component_metric_name: summary["component_metric_value"],
                "endpoint_radius": summary["endpoint_radius"],
                "matched_gt_endpoints": summary["matched_gt_endpoints"],
                "gt_endpoints": summary["gt_endpoints"],
                "preserved_components": summary["preserved_components"],
                "evaluable_components": summary["evaluable_components"],
                "per_image_csv": summary["per_image_csv"],
                "summary_json": summary["summary_json"],
            }
        )


def main():
    args = parse_args()
    if args.threshold_mode == "fixed" and args.threshold is None:
        raise ValueError("--threshold is required when --threshold-mode fixed")
    if args.threshold_mode == "fixed" and not (0.0 <= args.threshold <= 1.0):
        raise ValueError("--threshold must be in [0, 1]")

    pairs = load_image_pairs(args.pred_dir)
    best_f1 = sweep_best_f1(pairs, args.threshold_step)
    best_miou = sweep_best_miou(pairs, args.threshold_step)

    if args.threshold_mode == "fixed":
        anchor_threshold = float(args.threshold)
    else:
        anchor_threshold = float(best_f1["threshold"])

    (
        rows,
        cldice_mean,
        epr_dataset,
        cpr_dataset,
        matched_gt_endpoints,
        gt_endpoints,
        preserved_components,
        evaluable_components,
    ) = analyze_pairs(pairs, anchor_threshold, args.endpoint_radius)

    component_metric_name = args.component_metric_name.upper()
    summary = {
        "run_label": args.run_label,
        "pred_dir": str(Path(args.pred_dir).resolve()),
        "threshold_mode": args.threshold_mode,
        "anchor_threshold": anchor_threshold,
        "best_f1_threshold": float(best_f1["threshold"]),
        "best_f1": float(best_f1["f1"]),
        "best_precision": float(best_f1["precision"]),
        "best_recall": float(best_f1["recall"]),
        "best_miou_threshold": float(best_miou["threshold"]),
        "best_miou": float(best_miou["mIoU"]),
        "cldice": float(cldice_mean),
        "epr_at_r": float(epr_dataset),
        "component_metric_name": component_metric_name,
        "component_metric_value": float(cpr_dataset),
        "endpoint_radius": int(args.endpoint_radius),
        "matched_gt_endpoints": int(matched_gt_endpoints),
        "gt_endpoints": int(gt_endpoints),
        "preserved_components": int(preserved_components),
        "evaluable_components": int(evaluable_components),
        "num_images": len(rows),
        "per_image_csv": str(Path(args.per_image_csv).resolve()) if args.per_image_csv else "",
        "summary_json": str(Path(args.summary_json).resolve()) if args.summary_json else "",
    }

    if args.per_image_csv:
        write_per_image_csv(args.per_image_csv, rows)
    if args.summary_json:
        ensure_parent(args.summary_json)
        with open(args.summary_json, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
    if args.summary_csv:
        append_summary_csv(args.summary_csv, summary, component_metric_name)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
