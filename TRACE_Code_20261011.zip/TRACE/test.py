import argparse
import os
import cv2
import torch

from datasets import create_dataset
from models import build_sctr as build_model
from main import get_args_parser, target_to_uint8_mask, logits_to_uint8_prob_mask


parser = argparse.ArgumentParser('SCTR inference', parents=[get_args_parser()])
args = parser.parse_args()
args.phase = 'test'

if __name__ == '__main__':
    args.batch_size = args.batch_size_test
    device = torch.device(args.device)
    test_dl = create_dataset(args)
    if not args.checkpoint:
        raise ValueError('Please provide --checkpoint when running test.py')
    load_model_file = args.checkpoint
    model, _ = build_model(args)
    state_dict = torch.load(load_model_file, map_location=device)
    missing_keys, unexpected_keys = model.load_state_dict(state_dict["model"], strict=False)
    model.to(device)
    print("Load Model Successful!")
    if missing_keys:
        print("Missing keys:", missing_keys)
    if unexpected_keys:
        print("Unexpected keys:", unexpected_keys)
    suffix = os.path.splitext(os.path.basename(load_model_file))[0]
    save_root = args.save_root or os.path.join("./results/results_test", suffix)
    os.makedirs(save_root, exist_ok=True)
    with torch.no_grad():
        model.eval()
        for batch_idx, data in enumerate(test_dl):
            x = data["image"]
            target = data["label"]
            if device.type != 'cpu':
                x, target = x.cuda(), target.to(dtype=torch.int64).cuda()

            out = model(x)

            target = target[0, 0, ...].cpu().numpy()
            out = out[0, 0, ...].cpu().numpy()
            root_name = data["A_paths"][0].split("/")[-1][0:-4]
            target = target_to_uint8_mask(target)
            out = logits_to_uint8_prob_mask(out)

            print('----------------------------------------------------------------------------------------------')
            print(os.path.join(save_root, "{}_lab.png".format(root_name)))
            print(os.path.join(save_root, "{}_pre.png".format(root_name)))
            print('----------------------------------------------------------------------------------------------')
            cv2.imwrite(os.path.join(save_root, "{}_lab.png".format(root_name)), target)
            cv2.imwrite(os.path.join(save_root, "{}_pre.png".format(root_name)), out)

    print("Finished!")
