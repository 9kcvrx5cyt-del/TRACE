# Third-party notices

The root LICENSE is retained verbatim from the archived SCTR release (MIT, copyright 2026 spiderforest). Packaging does not remove or replace any existing source-file copyright notice.

- MixerCSeg: https://github.com/spiderforest/MixerCSeg. Encoder and training infrastructure are derived from this work; preserve the root license and original attribution.
- VMamba: https://github.com/MzeroMiko/VMamba. Its upstream MIT license (copyright 2024 MzeroMiko) is included in LICENSES/VMamba-MIT.txt.
- Mamba: https://github.com/state-spaces/mamba. Bundled mamba2 files identify this upstream source, and selective-scan sources retain Albert Gu and Tri Dao copyright headers. The upstream Apache-2.0 license is included in LICENSES/Mamba-Apache-2.0.txt.
- NVIDIA-derived helper code retains the full source-file copyright and redistribution conditions in VMamba/models/kernels/selective_scan/csrc/selective_scan/uninitialized_copy.cuh.

Dependency license texts were retrieved from the official upstream repositories on 2026-10-11. The precise upstream commit of the previously bundled dependency snapshot was not recorded in the archive; no version identity is implied by the retrieval date. Existing per-file notices continue to apply.

For this packaging release, executable Python/CUDA/C++ source files were not modified. Changes are limited to release documentation, dependency notices, exclusion of cache/Git metadata and private-machine batch scripts, and inclusion of the manuscript's split manifest and topology-evaluation helper. Third-party datasets and trained weights are not redistributed.
